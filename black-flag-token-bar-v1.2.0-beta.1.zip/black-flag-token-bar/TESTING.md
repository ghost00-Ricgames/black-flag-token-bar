# Black Flag Token Bar 1.2.0-beta.1 — Test Build

Source: feature/foundry-v14-black-flag-3 at commit 905411b4d6f57da9d666240bfba358bcf98fbed8.

This is not a published release. Its manifest and download updater properties are deliberately omitted.

## Install

Stop Foundry. Back up the world and any currently installed black-flag-token-bar directory. Extract this ZIP into the Foundry user data `Data/modules` folder; the ZIP includes a top-level `black-flag-token-bar` folder. Restart Foundry, enable the module, and use Foundry V14 with Black Flag 3.0.079.

## Test groups

1. Startup, draggable placement and reopening the world.
2. PC roster, HP, AC, Luck, and updates after edits.
3. Select NPC or PC tokens; test all displayed conditions and selected-token changes.
4. Roll requests for 6 ability checks, 6 saves, all skills, and death saves.
5. Visible versus hidden DC; confirm player cannot see the hidden number.
6. Test with one GM and one player account, actor ownership and private cards.
7. Clear module chat requests; verify unrelated chat is unaffected.
8. Repeat token tests with linked and unlinked tokens.

For each bug, provide a screenshot, step-by-step reproduction, expected and actual behavior, and browser console error if any. Please avoid testing in a sole copy of an important campaign world.
