Black Flag Token Bar 1.2.0-beta.2

Source branch: feature/foundry-v14-black-flag-3
Source commit: 06ea12eacd676e4197428c1ce9436a50b73b2db3

This local test package adds Foundry V14-native tooltips for condition names only. No other functional changes since beta.1.

Installation: Close Foundry, back up the old module directory and game world, unzip to Foundry User Data/Data/modules, and restart Foundry. The archive includes the black-flag-token-bar top-level folder.

Test: select a token, hover over each condition button, confirm only the condition name appears in a tooltip above the button, and verify toggling conditions still works. Repeat with another token. Source conditions are localized using Black Flag system labels.

This is a preview, not a public release. The manifest omits public release update URLs.
